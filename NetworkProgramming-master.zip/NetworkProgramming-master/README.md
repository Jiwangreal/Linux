# NetworkProgramming
Linux网络编程视频教程  
编译环境 Linux + CLion

视频地址 https://www.bilibili.com/video/av33813135/    
从p13 socket编程8开始在文件开头标注该代码属于哪个视频   

前面章节 echocli* echosrv* 依次按顺序匹配   

## linux编译
>> cmake .  
>> make

个人体会：之前没看这个，[muduo](https://github.com/834810071/muduo_study)基本上看不懂，看过之后，[muduo](https://github.com/834810071/muduo_study)基本上就没啥难度了。
